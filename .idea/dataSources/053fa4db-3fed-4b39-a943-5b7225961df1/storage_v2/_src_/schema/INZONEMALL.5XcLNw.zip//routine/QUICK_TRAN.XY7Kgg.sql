create FUNCTION QUICK_TRAN
/*
   敏感信息处理函数
   可以将银行卡号、身份证号、手机号、邮箱
   可以通过指定第三个参数为 r，把密文转为明文
   可以通过指定第三个参数为 t，把密文转为脱敏后的数据
   field 字段的可以取值为： backCardNo, idCardNo, mobileNo, email
   如果 field字段的值为 email， 只支持脱敏操作
   version 1.1
   author Kingh
   data 20181025
*/
(FIELD IN VARCHAR2, VALUE IN VARCHAR2, OPERATE IN VARCHAR2 DEFAULT 's') RETURN VARCHAR2

IS
       V_RESULT VARCHAR2(100);
       V_POSITION INT;
BEGIN
  -- 判断是否为解密操作
  IF OPERATE = 'r' THEN
     V_RESULT := TRANSLATE(VALUE,'KINGHSTBEM','0123456789');
  -- 判断是否为脱敏操作
  ELSIF OPERATE = 't' THEN
     V_RESULT := TRANSLATE(VALUE,'KINGHSTBEM','**********');
  ELSE
    -- 根据字段判断，如何进行脱敏
    IF FIELD = 'backCardNo' THEN
       V_RESULT := SUBSTR(value,0,6) || TRANSLATE(SUBSTR(value,7,LENGTH(VALUE)-10),'0123456789','KINGHSTBEM') || SUBSTR(value,-4,4);
    ELSIF FIELD = 'idCardNo' THEN
       V_RESULT := SUBSTR(value,0,6) || TRANSLATE(SUBSTR(value,7,LENGTH(VALUE)-10),'0123456789','KINGHSTBEM') || SUBSTR(value,-4,4);
    ELSIF FIELD = 'mobileNo' THEN
       V_RESULT := SUBSTR(value,0,3) || TRANSLATE(SUBSTR(value,4,LENGTH(VALUE)-7),'0123456789','KINGHSTBEM') || SUBSTR(value,-4,4);
    ELSIF FIELD = 'email' THEN
       V_POSITION := INSTR(VALUE,'@');
       IF V_POSITION <= 4 THEN
          -- 说明前面不足3位，取到前3位，后面的加*处理
          V_RESULT := SUBSTR(VALUE, 0, V_POSITION-1) || '***' || SUBSTR(VALUE, V_POSITION);
       ELSE
          -- 说明前面高于4位，取到前三位，后面加*处理
          V_RESULT := SUBSTR(VALUE, 0, 3) || '***' || SUBSTR(VALUE, V_POSITION);
       END IF;
    ELSE
       raise_application_error(-20012,'不支持的转换类型');
    END IF;
  END IF;

  RETURN V_RESULT;
END;
/


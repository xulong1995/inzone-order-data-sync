create view TBL_INZONE_ORG_VIEW as
select s.storecode as store_code,
       s.store_nm,
       '-1' as parent_code,
       '-1' as org_class,
       '' as busi_type
  from tbl_inzone_store s
 where s.dr = '0'
   and s.storecode = '0000'
union all
-- 区域
select t.region_no as store_code,
       t.region_name as store_nm,
       '0000' as parent_code,
       '0' as org_class,
       '' as busi_type
  from TBL_INZONE_REGION_INFO t
 where t.status = '1'
   and t.deleted = '0'
union all
-- 电器类
select s.store_id as store_code,
       s.store_nm,
       '1041' as parent_code,
       '1' as org_class,
       '' as busi_type
  from tbl_inzone_store s
 where s.dr = '0'
 -- 排除周大福珠宝
   and s.storecode not in ('0000','9998')
   and s.storecode in ('3333','3000')
union all
-- 门店
select s.store_id as store_code,
       s.store_nm,
       s.region_no as parent_code,
       '1' as org_class,
       '' as busi_type
  from tbl_inzone_store s
 where s.dr = '0'
   and s.storecode not in ('0000','9998', '3333','3000')
union all
-- 柜组
select t.org_code    as store_code,
       t.org_name    as store_nm,
       t.parent_code,
       t.org_class,
       t.busi_type
  from TBL_INZONE_ORGANIZATION t
union all
-- 专柜
select e.id as store_code,
       e.name as store_nm,
       e.frame2 as parent_code,
       '4' as org_class,
       '' as busi_type
  from pms_shoppe e
-- where e.status = '0'
   where e.isdel = '0'
/


create view V_OMS_ORDER as
SELECT
		a.order_id AS EXCHANGEID, -- 订单id
		--a.cid,
		a.customer_id AS CUSTOMERID, -- 客户号
		to_char(a.gmt_create,'yyyy-MM-dd HH24:mi:ss') AS ORDERTIME, -- 订单创建时间
		a.total_amount AS TOTALPRICE, -- 订单总金额(优惠前)
		a.pay_amount AS PAYAMT, -- 实际支付金额
		b.RECEIVER_PHONE AS PHONE, -- 收货人手机号
		-- a.phone AS PHONE, -- 买家手机号码
		a.user_remark AS REMARK, -- 用户备注
		to_char(b.out_stock_time,'yyyy-MM-dd HH24:mi:ss') AS SENDGOODSTIME, -- (出库时间|发货时间)
		to_char(a.finish_time,'yyyy-MM-dd HH24:mi:ss') AS WRITEOFFTIME, -- (订单完成时间|订单核销时间)
		a.write_off_phone AS WROOPERATOR, -- 核销操作员手机号
		b.operator AS SENDOPERATOR, -- 发货操作员手机号
		to_char(b.signed_time,'yyyy-MM-dd HH24:mi:ss') AS RECEIVETIME, -- 签收时间|确认收货时间
		to_char(a.gmt_modified,'yyyy-MM-dd HH24:mi:ss') AS MODIFYTIME, -- （更新时间|修改时间）
		a.service_charge AS FEE, -- 手续费
		a.store_id AS STORE_ID, -- 门店id
		c.invoice_extraction_code AS ERPFP, -- 发票提取码
		a.parent_order_id AS PORDERID, -- 父订单id
		a.discount AS DISCOUNT, -- 折扣金额
		a.discoupon AS DISCOUPON, -- 优惠券优惠金额
		a.order_sn AS ORDERSN, -- 秒杀订单号
		a.store_code AS ERPSTORECODE, -- （全渠道门店号|ERP门店号）`	44
		c.pay_machine_no AS SYJH, -- 款机号
		c.invoice_serial_no AS INVOICE, -- 小票流水号
		a.to_erp_status AS ERPSTATUS, -- 推送ERP状态
		to_char(a.to_erp_time,'yyyy-MM-dd HH24:mi:ss') AS ERPTIME, -- 推送ERP时间
		a.cancel_reason AS REJECTREASON, -- 商家拒绝接单原因
		to_char(b.receiving_time,'yyyy-MM-dd HH24:mi:ss') AS ODROPERATIME, -- 接单时间
		to_char(a.cancel_time,'yyyy-MM-dd HH24:mi:ss') AS ODRCANCELTIME, -- 取消时间
		to_char(a.expire_time,'yyyy-MM-dd HH24:mi:ss') AS ODRCLOSETIME, --(支付截止时间|订单关闭时间)
		a.pickupcode AS PICKUPCODE, -- 提货码
		a.shoppe_id AS SHOPPE_ID, -- 专柜id
		a.term_invoiceno AS TERMINVOICENO, -- 终端流水号
		TO_NUMBER(d.FAN_LI) AS GIFTAMOUNT, -- 赠款或返利
		a.consumpoints AS CONSUMPOINTS, -- 积分数量
		a.pointscash AS POINTSCASH, -- 积分抵现金数额(单位:分)
		b.detail_address AS DELIVERY_HOME, -- 详细地址
		b.receiver_name AS DELIVERY_NAME, -- 收货人姓名
		b.PROVINCE, -- 省份名称
		b.CITY, -- 城市名称
		b.AREA, -- 地区名称
		b.STREET, -- 街道名称
		--f.PROVID AS PROVID, -- 省份id
		--g.CITYID AS CITYID, -- 城市id
		--h.AREAID AS AREAID, -- 地区id
		a.direct_descent AS DIRECTDESCENT, -- 直降金额(单位:元)
		a.full_minus AS FULLMINUS, -- 满减金额(单位:元)
		a.full_arrival AS FULLARRIVAL, -- 满抵金额(单位:元)
		full_discount AS FULLDISCOUNT, -- 满折金额(单位:元)
		a.coupon_amount AS COUPONAMOUNT, -- 优惠券金额(单位:元)
		a.z_freight AS EXPRESS_FREIGHT, -- （总运费|快递运费）
		TO_NUMBER(d.MAN_YI_DOU) AS MANYIDOU_AMOUNT, -- 满益豆
		TO_NUMBER(d.YIN_DOU) AS YINDOU_AMOUNT, -- 银豆
		e.SETTLEDATE AS SETTLEDATE, -- 清算日期

    	CASE a.performance_channel
    		WHEN 'dexin' THEN '02'
    	END AS ORDER_FLAG, -- (履约渠道|订单标签) 用来判断是否是德信订单
    	
    	CASE a.delivery_type
    		WHEN 1 THEN '01'
    		WHEN 2 THEN '02'
    	END AS TAKETYPE, -- 配送方式
    
    	CASE a.order_status
    		WHEN 11 THEN '80'
    		WHEN 30 THEN '20'
    		WHEN 40 THEN '30'
    		WHEN 60 THEN '00'
    		WHEN 70 THEN '40'
    		WHEN 50 THEN '50'
    		WHEN 90 THEN '99'
    		WHEN 20 THEN '81'
    		--WHEN 0 THEN '82'
    		--WHEN 0 THEN '83'
    		--WHEN 0 THEN '84'
    		--WHEN 0 THEN '60'
    		--WHEN 0 THEN '61'
    		--WHEN 0 THEN '10'
    	END AS EXCHANGESTATUS, -- 订单状态（有问题，后续再补充）
    	
    	CASE a.channel_id
    		WHEN 'yunguangjie' THEN 'applet'
    		WHEN 'yunguangjie_app' THEN 'app'
    	END AS CHANNELNO, -- 下单渠道(app/小程序)
    	
    	CASE a.order_type
    		WHEN 127 THEN NULL
    		WHEN 1 THEN NULL
    		WHEN 3 THEN '01'
    		WHEN 4 THEN '02'
    	END AS ORDERTYPE -- 订单类型
    	
    FROM
    	order_info a
    LEFT JOIN order_delivery_detail b ON a.order_id = b.order_id
    LEFT JOIN order_invoice c ON a.order_id = c.order_id
    LEFT JOIN ORDER_PAYMENT_DETAIL d ON a.order_id = d.order_id
    LEFT JOIN OMS_PAYMENT_INFO e ON a.ORDER_ID = e.ORDER_ID

-- 	LEFT JOIN TBL_INZONE_DELIVERY_ADDR f ON b.PROVINCE = SUBSTR(f.HOME, 0, 2)
-- 	LEFT JOIN TBL_INZONE_DELIVERY_ADDR g ON b.CITY = SUBSTR(g.HOME, 4, 3)
-- 	LEFT JOIN TBL_INZONE_DELIVERY_ADDR h ON b.AREA = SUBSTR(h.HOME, 8, 3)
/


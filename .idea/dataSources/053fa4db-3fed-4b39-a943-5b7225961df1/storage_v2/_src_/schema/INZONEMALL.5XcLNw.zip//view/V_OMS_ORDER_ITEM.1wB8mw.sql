create view V_OMS_ORDER_ITEM as
SELECT
	a.order_item_id AS ID,-- 订单明细id
	a.order_id AS EXCHANGEID,-- 订单id
	b.store_id AS STORE_ID,-- 兑换门店号
	a.fx_store_id AS FROMSTORE_ID,--商品展示来源门店号
	e.STORE_NM AS STORE_NM,-- 兑换门店名称
	a.spu_id AS SPU_ID,-- 商品spu id
	a.spu_name AS SPU_NAME,-- 商品spu名称
	a.PRODUCT_IMG AS SKU_PIC,-- sku图片
	NULL AS URL,-- spu图片地址
	a.brand AS BRAND_ID,-- 品牌id
	a.category AS CATEGORY_ID,-- 商品分类id
	a.sku_id AS SKU_ID,-- 商品sku id
	a.sku_name AS SKU_NAME,-- 商品sku名称
	a.sale_price AS SKU_PRICE,-- 商品单价
	a.sale_quantity AS SKU_QUANTITY,-- 购买数量
	NULL AS SKU_ATTRS_VALS,-- 商品组合属性(目前用不到，设为null)
	a.fx_per_phone AS DISTRIBUTOR,-- 分销人手机号
	a.live_room_id AS ROOM_NUM,-- 直播间id
	--h.SKU_DESC AS SKU_DESC,-- sku描述
	a.STORE_EXTRACT_RATIO AS FROMDISTRIBUNUM,-- 门店分润比例（%）
	a.STORE_EXTRACT_METHOD AS FROMSTOREISALLOWDIST,-- 商品展示来源门店是否被允许分销,1-允许
	a.discount AS DISCOUNT,-- 商品促销活动折扣金额
	a.discoupon AS DISCOUPON,-- 商品使用优惠券，优惠分摊金额
	a.row_no AS ROWNO,-- 商品行号
	c.logistics_sn AS LOGISTICS_NO,-- （运单号|物流单号）
	a.sku_num AS SKU_NUM,-- 传ERP的商品编码
	CASE
		a.product_type 
		WHEN 3 THEN
		1 ELSE 0 
	END AS ISCOMBINEDCODE,-- 是否组合商品(0否，1是)
	a.consumpoints AS CONSUMPOINTS,-- 积分
	a.pointscash AS POINTSCASH,-- 积分抵现金额(单位:分)
	a.location_id AS LOCATION_ID,-- erp库位id
	a.direct_descent AS DIRECTDESCENT,-- 直降金额(单位:元)
	a.full_minus AS FULLMINUS,-- 满减金额(单位:元)
	a.full_arrival AS FULLARRIVAL,-- 满抵金额(单位:元)
	a.full_discount AS FULLDISCOUNT,-- 满折金额(单位:元)
	a.coupon_amount AS COUPONAMOUNT,-- 优惠券金额(单位:元)
	a.sku_no AS SKU_NO,-- 货号
	CASE
		a.product_type 
		WHEN 4 THEN 1 ELSE 0 
	END AS FREIGHT_MARK,-- 是否运费标识 0：否，1:是
	f.STORE_NM AS fromstore_nm,-- 商品展示来源门店名称
	0 AS dist_amt,-- 个人所得佣金，暂时设为0
	0 AS fromdist_amt,-- 门店所得佣金，暂时设为0
	--a.order_source AS ORDER_SOURCE, -- 订单来源
	CASE a.order_source
		WHEN '01' THE '自发'
		WHEN '02' THEN '分销'
		WHEN '03' THEN '直播'
		WHEN '04' THEN '导购'
	END AS ORDER_SOURCE  -- 订单来源
	
FROM
	order_item a
	INNER JOIN order_info b ON a.order_id = b.order_id
	LEFT JOIN order_delivery_logistics c ON a.order_item_id = c.order_item_id
	LEFT JOIN TBL_INZONE_STORE e ON b.STORE_ID = e.STORE_ID
	LEFT JOIN TBL_INZONE_STORE f ON a.FX_STORE_ID = f.STORE_ID
-- 	LEFT JOIN PMS_SPU_IMAGE g ON a.SPU_ID = g.SPU_ID AND g.TYPE = '00'
-- 	LEFT JOIN PMS_SKU_INFO h ON a.SKU_ID = h.ID
/


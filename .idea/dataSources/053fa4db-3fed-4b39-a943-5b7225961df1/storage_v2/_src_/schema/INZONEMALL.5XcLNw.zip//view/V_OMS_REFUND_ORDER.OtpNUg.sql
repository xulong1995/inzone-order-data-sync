create view V_OMS_REFUND_ORDER as
(
	select
	a.after_sale_order_id AS ID, -- 退货id
	a.order_id AS EXCHANGEID, -- 订单id
	e.CUSTOMER_ID AS CUSTOMERID, -- 客户号
	e.store_id AS STORE_ID, -- 门店号
	g.gz AS SHOPPE_ID, -- 专柜号
	CASE b.pay_type
		WHEN 10 THEN '2'
		WHEN 20 THEN '1'
		WHEN 30 THEN '5'
		WHEN 40 THEN '8'
		WHEN 50 THEN '6'
		WHEN 60 THEN '9'
	END AS PAYTYPE, -- 支付方式
	
	to_char(a.create_date,'yyyy-MM-dd HH24:mi:ss') AS REFUNDTIME, -- 退货时间
	to_char(b.REFUND_PAY_TIME,'yyyy-MM-dd HH24:mi:ss') AS COMPLETETIME, -- 退款/退货退款完成时间
	b.refund_amount AS TRANAMT, -- 退款金额（单位：分）

	CASE a.status
		--WHEN 0 THEN '0'
		WHEN '30' THEN '62'
		WHEN '32' THEN '89'
		WHEN '40' THEN '80'
		WHEN '41' THEN '80'
		WHEN '50' THEN '84'
		WHEN '51' THEN '83'
		WHEN '60' THEN '99'
		WHEN '61' THEN '99'
		--WHEN 127 THEN '0'
    ELSE a.status
	END AS REFUNDSTATUS, -- 退货状态

	--null, -- 微信状态
	--null, -- 微信状态描述
	--null, -- 退货操作员
	a.operator AS APPROPERATOR, -- 审核人员
	to_char(a.audit_date,'yyyy-MM-dd HH24:mi:ss') AS APPROVETIME, -- 审核时间
	--null, -- 备用字段1
	--null, -- 备用字段2
	b.out_trade_no AS PAYMENTID, -- (交易单号|支付流水号)

	CASE a.applyer_type
		WHEN 'buyer' THEN '1'
		ELSE '0'
	END AS TYPE, -- 类型 0 管理端退货 1 小程序申请

	--null, -- 原订单状态
	CASE e.order_status
			WHEN 11 THEN '80'
			WHEN 30 THEN '20'
			WHEN 40 THEN '30'
			WHEN 60 THEN '00'
			WHEN 70 THEN '40'
			WHEN 50 THEN '50'
			WHEN 90 THEN '99'
			WHEN 20 THEN '81'
			--WHEN 0 THEN '82'
			--WHEN 0 THEN '83'
			--WHEN 0 THEN '84'
			--WHEN 0 THEN '60'
			--WHEN 0 THEN '61'
			--WHEN 0 THEN '10'
		END AS ORDERSTATUS, -- 原订单状态
	--null, -- 是否退货过期
	--a.settle_date AS SETTLEDATE, -- 清算日期
	to_char(f.SETTLEDATE,'yyyy-MM-dd') AS SETTLEDATE, -- 清算日期
	c.pay_machine_no AS SYJH, -- 款机号
	c.invoice_serial_no AS INVOICE, -- 小票流水号
	a.to_erp_status AS ERPSTATUS, -- 推送ERP状态
	to_char(a.to_erp_time,'yyyy-MM-dd HH24:mi:ss') AS ERPTIME, -- 推送ERP时间
	--null, -- 售后单类型
	a.process_reason AS REJECTREASON, -- 审核原因
	a.apply_reason AS REFUNDREASON, -- 申请退款的原因
	a.procedure_fee AS REFUNDFEE, -- 退款手续费
	a.invoice_state AS INVOICESTATE, -- 红冲发票状态
	to_char(a.invoice_date,'yyyy-MM-dd HH24:mi:ss') AS INVOICETIME, -- 红冲发票时间
	a.terminal_seril_no AS TERMINVOICENO, -- （终端号|终端流水号）
	a.efuture_aftersale_id AS BASEID, -- 全渠道退货订单编号
	--null, -- 扣回金额
	--null, -- 补偿金额
	
	CASE a.channel_id
		WHEN 'yunguangjie' THEN 'applet'
		WHEN 'yunguangjie_app' THEN 'app'
	END AS CHANNELNO, -- 下单渠道(app/小程序)
	
	--null, -- 视频号同步状态
	d.man_yi_dou AS MANYIDOU_AMOUNT, -- 满益豆支付金额
	d.yin_dou AS YINDOU_AMOUNT, -- 银豆退款金额

	CASE
		e.order_type
		WHEN 127 THEN '1'
		ELSE '0'
	END AS MERCHANT_USER-- 入驻商户标识 0:自营 1:入驻商户

	
	from
	after_sale_order_info a
	left join after_sale_refund b on a.after_sale_order_id = b.after_sale_id
	left JOIN order_invoice c on a.after_sale_order_id = c.order_id
	left JOIN order_payment_detail d on a.order_id = d.order_id
	left join order_info e on a.order_id = e.order_id
	left join order_item g on a.order_id = g.order_id
	LEFT JOIN OMS_REFUND_INFO f ON a.AFTER_SALE_ORDER_ID = f.REFUND_ORDER_ID
	)
/


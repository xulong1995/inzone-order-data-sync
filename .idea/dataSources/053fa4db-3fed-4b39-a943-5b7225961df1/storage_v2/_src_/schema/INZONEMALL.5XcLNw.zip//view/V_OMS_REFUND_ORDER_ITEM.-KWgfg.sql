create view V_OMS_REFUND_ORDER_ITEM as
SELECT
	a.AFTER_SALE_ITEM_ID AS ID,-- 订单明细id
	a.AFTER_SALE_ORDER_ID AS REFUND_ORDER_ID,-- 售后单id
	a.ORDER_ID AS EXCHANGEID,-- 订单id
	c.store_id AS STORE_ID,-- 兑换门店号
	f.store_nm AS STORE_NM,-- 兑换门店名称
	d.fx_store_id AS FROMSTORE_ID,--商品展示来源门店号
	e.STORE_NM AS FROMSTORE_NM,--商品展示来源门店名称
	0 AS FROMDIST_AMT, --商品展示来源门店获得分销佣金 单位分
	a.spu_id AS SPU_ID,-- 商品spu id
	a.spu_name AS SPU_NAME,-- 商品spu名称
	d.brand AS BRAND_ID,-- 品牌id
	a.sku_id AS SKU_ID,-- 商品sku id
	d.sku_name AS SKU_NAME,-- 商品sku名称
	a.SKU_PRICE AS SKU_PRICE,-- 商品单价
	a.APPLY_NUMBER AS SKU_QUANTITY,-- 申请售后的数量
	d.fx_per_phone AS DISTRIBUTOR,-- 分销人手机号
	0 AS DIST_AMT, --分销佣金，单位分
	a.discount AS DISCOUNT,-- 商品促销活动折扣金额
	a.discoupon AS DISCOUPON,-- 商品使用优惠券，优惠分摊金额
	a.pointscash AS POINTSCASH, -- 积分抵现金额(单位:分)
  a.CONSUMPOINTS AS CONSUMPOINTS,
  d.sku_num AS SKU_NUM,
	d.sku_no AS SKU_NO,-- 货号
	d.row_no AS ROWNO,-- 商品行号
	d.direct_descent AS DIRECTDESCENT,-- 直降金额(单位:元)
	d.full_minus AS FULLMINUS,-- 满减金额(单位:元)
	d.full_arrival AS FULLARRIVAL,-- 满抵金额(单位:元)
	d.full_discount AS FULLDISCOUNT,-- 满折金额(单位:元)
	d.coupon_amount AS COUPONAMOUNT,-- 优惠券金额(单位:元)
	d.location_id AS LOCATION_ID,-- erp库位id
  CASE
		d.product_type
		WHEN 3 THEN
		1 ELSE 0
	END AS ISCOMBINEDCODE-- 是否组合商品(0否，1是)
FROM
	AFTER_SALE_ORDER_ITEM a
	LEFT JOIN AFTER_SALE_ORDER_INFO b ON a.AFTER_SALE_ORDER_ID = b.AFTER_SALE_ORDER_ID
	LEFT JOIN ORDER_INFO c ON a.ORDER_ID = c.ORDER_ID
	LEFT JOIN ORDER_ITEM d on a.order_id = d.order_id
	LEFT JOIN TBL_INZONE_STORE e ON d.fx_store_id = e.STORE_ID
	LEFT JOIN TBL_INZONE_STORE f ON c.store_id = f.STORE_I
/


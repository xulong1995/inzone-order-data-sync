create definer = xingxzh@`%` event e_create_partition_order_info on schedule
    every '1' MONTH
        starts '2023-03-01 01:05:00'
    on completion preserve
    enable
    do
    call create_partition_by_month('order_info');


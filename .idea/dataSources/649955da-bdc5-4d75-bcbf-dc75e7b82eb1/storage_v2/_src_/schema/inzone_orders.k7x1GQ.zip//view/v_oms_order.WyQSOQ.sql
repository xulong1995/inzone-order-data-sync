create view v_oms_order as
select `a`.`order_id`                                     AS `order_id`,
       `a`.`cid`                                          AS `cid`,
       `a`.`gmt_create`                                   AS `gmt_create`,
       `a`.`delivery_type`                                AS `delivery_type`,
       `a`.`total_amount`                                 AS `total_amount`,
       ''                                                 AS `Name_exp_6`,
       `a`.`pay_amount`                                   AS `pay_amount`,
       `a`.`phone`                                        AS `phone`,
       `a`.`user_remark`                                  AS `user_remark`,
       `a`.`order_status`                                 AS `order_status`,
       `a`.`channel_id`                                   AS `channel_id`,
       ''                                                 AS `Name_exp_12`,
       ''                                                 AS `Name_exp_13`,
       ''                                                 AS `Name_exp_14`,
       ''                                                 AS `Name_exp_15`,
       `b`.`out_stock_time`                               AS `out_stock_time`,
       `a`.`finish_time`                                  AS `finish_time`,
       `a`.`write_off_phone`                              AS `write_off_phone`,
       `b`.`operator`                                     AS `operator`,
       `b`.`signed_time`                                  AS `signed_time`,
       ''                                                 AS `Name_exp_21`,
       `a`.`gmt_modified`                                 AS `gmt_modified`,
       ''                                                 AS `Name_exp_23`,
       `a`.`service_charge`                               AS `service_charge`,
       `a`.`store_id`                                     AS `store_id`,
       `a`.`channel_id`                                   AS `channel_id`,
       ''                                                 AS `Name_exp_27`,
       ''                                                 AS `Name_exp_28`,
       `c`.`invoice_extraction_code`                      AS `invoice_extraction_code`,
       `a`.`parent_order_id`                              AS `parent_order_id`,
       ''                                                 AS `Name_exp_31`,
       `a`.`discount`                                     AS `discount`,
       `a`.`discoupon`                                    AS `discoupon`,
       `a`.`order_type`                                   AS `order_type`,
       `a`.`order_sn`                                     AS `order_sn`,
       ''                                                 AS `Name_exp_36`,
       `a`.`performance_channel`                          AS `performance_channel`,
       `a`.`store_code`                                   AS `store_code`,
       `c`.`pay_machine_no`                               AS `pay_machine_no`,
       `c`.`invoice_serial_no`                            AS `invoice_serial_no`,
       `a`.`to_erp_status`                                AS `to_erp_status`,
       `a`.`to_erp_time`                                  AS `to_erp_time`,
       `a`.`cancel_reason`                                AS `cancel_reason`,
       `a`.`cancel_time`                                  AS `cancel_time`,
       `a`.`expire_time`                                  AS `expire_time`,
       `a`.`pickupcode`                                   AS `pickupcode`,
       `a`.`shoppe_id`                                    AS `shoppe_id`,
       ''                                                 AS `Name_exp_48`,
       `a`.`term_invoiceno`                               AS `term_invoiceno`,
       `a`.`giftamount`                                   AS `giftamount`,
       `a`.`consumpoints`                                 AS `consumpoints`,
       `a`.`pointscash`                                   AS `pointscash`,
       `b`.`detail_address`                               AS `detail_address`,
       `b`.`receiver_name`                                AS `receiver_name`,
       concat(`b`.`province`, `b`.`city`, `b`.`area`)     AS `CONCAT( b.province, b.city, b.area )`,
       `b`.`detail_address`                               AS `detail_address`,
       ''                                                 AS `Name_exp_57`,
       ''                                                 AS `Name_exp_58`,
       ''                                                 AS `Name_exp_59`,
       ''                                                 AS `Name_exp_60`,
       `a`.`channel_id`                                   AS `channel_id`,
       `a`.`direct_descent`                               AS `direct_descent`,
       `a`.`full_minus`                                   AS `full_minus`,
       `a`.`full_arrival`                                 AS `full_arrival`,
       `a`.`full_discount`                                AS `full_discount`,
       `a`.`coupon_amount`                                AS `coupon_amount`,
       ''                                                 AS `Name_exp_67`,
       ''                                                 AS `Name_exp_68`,
       ''                                                 AS `Name_exp_69`,
       ''                                                 AS `Name_exp_70`,
       ''                                                 AS `Name_exp_71`,
       (case `a`.`order_type` when 127 then 1 else 0 end) AS `CASE
			a.order_type 
			WHEN 127 THEN
			1 ELSE 0 
		END`,
       `a`.`z_freight`                                    AS `z_freight`
from ((`inzone_orders`.`order_info` `a` left join `inzone_orders`.`order_delivery_detail` `b` on ((`a`.`order_id` = `b`.`order_id`)))
         left join `inzone_orders`.`order_invoice` `c` on ((`a`.`order_id` = `c`.`order_id`)));

-- comment on column v_oms_order.EXCHANGEID not supported: 订单编号

-- comment on column v_oms_order.CUSTOMERID not supported: 会员编号

-- comment on column v_oms_order.ORDERTIME not supported: 创建时间

-- comment on column v_oms_order.TAKETYPE not supported: 配送方式  1, "自提";  2, "快递";3, "外卖"

-- comment on column v_oms_order.TOTALPRICE not supported: 优惠前交易总金额（以分为单位存储）

-- comment on column v_oms_order.PAYAMT not supported: 实际交易支付金额

-- comment on column v_oms_order.PHONE not supported: 买家手机号

-- comment on column v_oms_order.REMARK not supported: 用户备注

-- comment on column v_oms_order.EXCHANGESTATUS not supported: 10：待付款，20：待接单，30：待发货，40：

-- comment on column v_oms_order.SOURCETYPE not supported: 接入方业务线标识  xyzdj, "银座超市到家" yunguangjie 云逛街  inzone-app商城

-- comment on column v_oms_order.SENDGOODSTIME not supported: 出库时间

-- comment on column v_oms_order.WRITEOFFTIME not supported: 订单完成时间（自提收货，配送的确认收货）

-- comment on column v_oms_order.WROOPERATOR not supported: 核销操作员手机号

-- comment on column v_oms_order.SENDOPERATOR not supported: 操作人手机号

-- comment on column v_oms_order.RECEIVETIME not supported: 签收时间

-- comment on column v_oms_order.MODIFYTIME not supported: 更新时间

-- comment on column v_oms_order.FEE not supported: 手续费

-- comment on column v_oms_order.STORE_ID not supported: 门店编号

-- comment on column v_oms_order.ORDER_SOURCE not supported: 接入方业务线标识  xyzdj, "银座超市到家" yunguangjie 云逛街  inzone-app商城

-- comment on column v_oms_order.ERPFP not supported: 发票提取码

-- comment on column v_oms_order.PORDERID not supported: 父订单编号

-- comment on column v_oms_order.DISCOUNT not supported: 折扣金额（分）

-- comment on column v_oms_order.DISCOUPON not supported: 优惠金额（分）

-- comment on column v_oms_order.ORDERTYPE not supported: 订单类型 1:一般订单  2：虚拟订单，3 预售订单  4 秒杀订单  5 拼团订单  127 其他

-- comment on column v_oms_order.ORDERSN not supported: 秒杀服务订单号

-- comment on column v_oms_order.ORDER_FLAG not supported: 履约渠道：dexin;

-- comment on column v_oms_order.ERPSTORECODE not supported: 全渠道门店编码

-- comment on column v_oms_order.SYJH not supported: 款机号

-- comment on column v_oms_order.INVOICE not supported: 小票流水号，正向与逆向单的号是不一样的

-- comment on column v_oms_order.ERPSTATUS not supported: 同步ERP状态  0 待推送1 推送成功 2 推送失败  3 推送中

-- comment on column v_oms_order.ERPTIME not supported: 推送ERP时间

-- comment on column v_oms_order.REJECTREASON not supported: 取消原因

-- comment on column v_oms_order.ODROPERATIME not supported: 订单取消时间

-- comment on column v_oms_order.ODRCLOSETIME not supported: 支付订单截止时间

-- comment on column v_oms_order.PICKUPCODE not supported: 提货码

-- comment on column v_oms_order.SHOPPE_ID not supported: 专柜 id

-- comment on column v_oms_order.TERMINVOICENO not supported: 终端流水号

-- comment on column v_oms_order.GIFTAMOUNT not supported: 返利金额（分）

-- comment on column v_oms_order.CONSUMPOINTS not supported: 积分

-- comment on column v_oms_order.POINTSCASH not supported: 积分抵现金额（分）

-- comment on column v_oms_order.ORDER_ADDRESS not supported: 详细地址

-- comment on column v_oms_order.DELIVERY_NAME not supported: 收货人姓名

-- comment on column v_oms_order.DELIVERY_HOME not supported: 详细地址

-- comment on column v_oms_order.CHANNELNO not supported: 接入方业务线标识  xyzdj, "银座超市到家" yunguangjie 云逛街  inzone-app商城

-- comment on column v_oms_order.DIRECTDESCENT not supported: 直降

-- comment on column v_oms_order.FULLMINUS not supported: 满减

-- comment on column v_oms_order.FULLARRIVAL not supported: 满抵

-- comment on column v_oms_order.FULLDISCOUNT not supported: 满折

-- comment on column v_oms_order.COUPONAMOUNT not supported: 目前认为是电子优惠券，根据后期需求进行调整

-- comment on column v_oms_order.EXPRESS_FREIGHT not supported: 总运费


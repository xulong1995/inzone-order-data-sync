create view v_oms_refund_order as
select `a`.`after_sale_order_id`                                AS `after_sale_order_id`,
       `a`.`order_id`                                           AS `order_id`,
       NULL                                                     AS `NULL`,
       `b`.`pay_type`                                           AS `pay_type`,
       `a`.`create_date`                                        AS `create_date`,
       `b`.`refund_amount`                                      AS `refund_amount`,
       `b`.`refund_status`                                      AS `refund_status`,
       NULL                                                     AS `NULL`,
       NULL                                                     AS `NULL`,
       NULL                                                     AS `NULL`,
       `a`.`operator`                                           AS `operator`,
       `a`.`audit_date`                                         AS `audit_date`,
       NULL                                                     AS `NULL`,
       NULL                                                     AS `NULL`,
       `b`.`out_trade_no`                                       AS `out_trade_no`,
       (case `a`.`applyer_type` when 'buyer' then 1 else 0 end) AS `case a.applyer_type when "buyer" then 1
	else 0 end`,
       NULL                                                     AS `NULL`,
       NULL                                                     AS `NULL`,
       `a`.`settle_date`                                        AS `settle_date`,
       `c`.`pay_machine_no`                                     AS `pay_machine_no`,
       `c`.`invoice_serial_no`                                  AS `invoice_serial_no`,
       `a`.`to_erp_status`                                      AS `to_erp_status`,
       `a`.`to_erp_time`                                        AS `to_erp_time`,
       NULL                                                     AS `NULL`,
       `a`.`process_reason`                                     AS `process_reason`,
       `a`.`apply_reason`                                       AS `apply_reason`,
       `a`.`invoice_date`                                       AS `invoice_date`,
       `a`.`procedure_fee`                                      AS `procedure_fee`,
       `a`.`invoice_state`                                      AS `invoice_state`,
       `a`.`invoice_date`                                       AS `invoice_date`,
       `a`.`terminal_seril_no`                                  AS `terminal_seril_no`,
       `a`.`efuture_aftersale_id`                               AS `efuture_aftersale_id`,
       NULL                                                     AS `NULL`,
       NULL                                                     AS `NULL`,
       `a`.`channel_id`                                         AS `channel_id`,
       NULL                                                     AS `NULL`,
       `d`.`man_yi_dou`                                         AS `man_yi_dou`,
       (case `e`.`order_type` when 127 then 1 else 0 end)       AS `CASE
			e.order_type 
			WHEN 127 THEN
			1 ELSE 0 
		END`,
       `d`.`yin_dou`                                            AS `yin_dou`
from ((((`inzone_orders`.`after_sale_order_info` `a` left join `inzone_orders`.`after_sale_refund` `b` on ((`a`.`after_sale_order_id` = `b`.`after_sale_id`))) left join `inzone_orders`.`order_invoice` `c` on ((`a`.`after_sale_order_id` = `c`.`order_id`))) left join `inzone_orders`.`order_payment_detail` `d` on ((`a`.`order_id` = `d`.`order_id`)))
         left join `inzone_orders`.`order_info` `e` on ((`a`.`order_id` = `e`.`order_id`)));

-- comment on column v_oms_refund_order.ID not supported: 售后单号

-- comment on column v_oms_refund_order.EXCHANGEID not supported: 订单号

-- comment on column v_oms_refund_order.PAYTYPE not supported: 支付类型

-- comment on column v_oms_refund_order.REFUNDTIME not supported: 申请售后时间

-- comment on column v_oms_refund_order.TRANAMT not supported: 退款金额

-- comment on column v_oms_refund_order.REFUNDSTATUS not supported: 退款状态

-- comment on column v_oms_refund_order.APPROPERATOR not supported: 审核人员工号

-- comment on column v_oms_refund_order.APPROVETIME not supported: 审核时间

-- comment on column v_oms_refund_order.PAYMENTID not supported: 交易单号

-- comment on column v_oms_refund_order.SETTLEDATE not supported: 清算时间

-- comment on column v_oms_refund_order.SYJH not supported: 款机号

-- comment on column v_oms_refund_order.INVOICE not supported: 小票流水号，正向与逆向单的号是不一样的

-- comment on column v_oms_refund_order.ERPSTATUS not supported: 同步ERP状态 0未同步，1同步成功，2同步失败

-- comment on column v_oms_refund_order.ERPTIME not supported: 推送ERP时间

-- comment on column v_oms_refund_order.REJECTREASON not supported: 审核意见原因

-- comment on column v_oms_refund_order.REFUNDREASON not supported: 申请原因

-- comment on column v_oms_refund_order.COMPLETETIME not supported: 红冲发票时间

-- comment on column v_oms_refund_order.REFUNDFEE not supported: 退款手续费,单位分

-- comment on column v_oms_refund_order.INVOICESTATE not supported: 红冲发票状态0没有发起红冲;1红冲成功;2红冲失败;3蓝票不存在，审核通过时，会先红冲，再退款

-- comment on column v_oms_refund_order.INVOICETIME not supported: 红冲发票时间

-- comment on column v_oms_refund_order.TERMINVOICENO not supported: 终端号

-- comment on column v_oms_refund_order.BASEID not supported: 全渠道退货单号

-- comment on column v_oms_refund_order.CHANNELNO not supported: 接入方业务线标识  xyzdj, "银座超市到家" yunguangjie 云逛街  inzone-app商城

